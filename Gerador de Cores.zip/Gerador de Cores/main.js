
function start() {

    const cores = ['red','green','yellow','pink','black', 'white', 
    'blue', 'brown','darkblue','orange','orangered','gray', 'violet'];

    const h1 = document.querySelector("h1");

    document.querySelector("button").addEventListener("click", () => {
        const sort = Math.floor(Math.random() * cores.length);

        h1.innerHTML = `background-color: ${cores[sort]}`; 
        document.body.style.background = `${cores[sort]}`;

        console.log(cores[sort]);
        
        if(document.body.style.background == 'white'){
            h1.style.color = 'black';
        }else{
            h1.style.color = '#fff';
        }
    });

}
start();